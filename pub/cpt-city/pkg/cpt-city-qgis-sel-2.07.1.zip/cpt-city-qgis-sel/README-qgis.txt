This package contains a selection of the cpt-city gradients for use by the QGIS application.

The gradients files chosen allow for redistribution and free use, 
subject to individual license information found in the COPYING.xml files.

